# Essentials of Compilation

Tracking the [Essentials of Compilation](https://jeapostrophe.github.io/courses/2021/spring/406/notes/book.pdf) course, with my own solutions and code here and there.
Requires `racket`.

The compiler emits aarch64 assembly; I use the aarch64 linux cross-compiler and qemu to run them.
